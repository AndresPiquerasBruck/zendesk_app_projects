# Fetch client data from a database and show it on the ticket view

[When the agent clicks a ticket view, if the client is in the database, it displays a table with all the information available on the database.]

### Screenshot(s):
![image](https://github.com/user-attachments/assets/61e1740e-98f2-485f-ad31-395d5cab07f3)
